from __future__ import print_function, absolute_import, division

from six import iteritems

import cobrame
from ecolime.corrections import correct_trna_modifications

amino_acid_trna_synthetase = {
  "cys_L_c": "CysS_mono",
  "leu_L_c": "LeuS_mono",
  "lys_L_c": "generic_LYSINEaaRS",
  "asp_L_c": "AspS_dim",
  "phe_L_c": "PheS_tetra",
  "his_L_c": "HisS_dim",
  "asn_L_c": "AsnS_dim",
  "pro_L_c": "ProS_dim",
  "ala_L_c": "AlaS_tetra",
  "ile_L_c": "IleS_mono",
  "ser_L_c": "SerS_dim",
  "arg_L_c": "ArgS_mono",
  "met_L_c": "MetS_dim",
  "tyr_L_c": "TyrS_dim",
  "glu_L_c": "GltX_mono",
  "thr_L_c": "ThrS_dim",
  "val_L_c": "ValS_mono",
  "gly_c": "GlyS_tetra",
  "trp_L_c": "TrpS_dim_mod_mg2"
}

trna_modification = {'D_at_20A': {'machines': ['generic_Dus'],
                                  'metabolites': {'nadph_c': -1,
                                                  'h_c': -1,
                                                  'nadp_c': 1}},

                     'D_at_20': {'machines': ['generic_Dus'],  
                                 'metabolites': {'nadph_c': -1,
                                                 'h_c': -1,
                                                 'nadp_c': 1}},

                     't6A_at_37': {'machines': ['TsaC_mono'],
                                   'metabolites': {'hco3_c': -1,
                                                   'thr_L_c': -1,
                                                   'atp_c': -1,
                                                   'amp_c': 1,
                                                   'h_c': 1,
                                                   'h2o_c': 1,
                                                   'ppi_c': 1}},

                     'm7G_at_46': {'machines': ['TrmB_mono'],
                                   'metabolites': {'amet_c': -1,
                                                   'ahcys_c': 1,
                                                   'h_c': 1}},

                     'acp3U_at_47': {'machines': [],
                                     'metabolites': {'amet_c': -1,
                                                     '5mta_c': 1,
                                                     'h_c': 1}},

                     'm5U_at_54': {'machines': ['TrmFO_mono'],
                                   'metabolites': {'amet_c': -1,
                                                   'ahcys_c': 1,
                                                   'h_c': 1}},

                     'Y_at_55': {'machines': ['TruB_mono'],  
                                 'metabolites': {}},

                     'Y_at_65': {'machines': ['TruB_mono'],
                                 'metabolites': {}},

                     'D_at_17': {'machines': ['generic_Dus'],  
                                 'metabolites': {'nadph_c': -1,
                                                 'h_c': -1,
                                                 'nadp_c': 1}},

                     'cmo5U_at_34': {'machines': ['MetK_mono', 'TrmR_mono'],
                                     'metabolites': {'amet_c': -1,
                                                     'chor_c': -2,
                                                     'ahcys_c': 1,
                                                     'h_c': 1,
                                                     'phpyr_c': 1,
                                                     'pphn_c': 1}},

                     'D_at_16': {'machines': ['generic_Dus'],  
                                 'metabolites': {'nadph_c': -1,
                                                 'h_c': -1,
                                                 'nadp_c': 1}},

                     'Q_at_34': {
                     'machines': ['Tgt_hexa', 'QueA_mono',
                                  'QueG_mono'],
                     'metabolites': {'amet_c': -1,
                                     'gua_c': 1,
                                     'ade_c': 1,
                                     'met_L_c': 1,
                                     'h_c': 2}},

                     'm2A_at_37': {'machines': [],
                                   'metabolites': {'amet_c': -1,
                                                   'ahcys_c': 1,
                                                   'h_c': 1}},

                     's4U_at_8': {'machines': ['TrmU_mono'],
                                  'carriers': {'trdrd_c': -1,
                                               'trdox_c': 1,
                                               'IscS_mod_2:pydx5p_mod_1:SH':
                                                   -1,
                                               'IscS_mod_2:pydx5p': 1},
                                  'metabolites': {'atp_c': -1,
                                                  'amp_c': 1,
                                                  'ppi_c': 1,
                                                  'h_c': 1}},

                     'm6t6A_at_37': {'machines': ['TsaC_mono'],
                                     'metabolites': {'amet_c': -1,
                                                     'atp_c': -1,
                                                     'hco3_c': -1,
                                                     'thr_L_c': -1,
                                                     'ahcys_c': 1,
                                                     'amp_c': 1,
                                                     'h_c': 2,
                                                     'h2o_c': 1,
                                                     'ppi_c': 1}},



                     'Y_at_40': {'machines': ['TruA_dim'],  
                                 'metabolites': {}},


                     'Um_at_32': {'machines': [],
                                  'metabolites': {'amet_c': -1,
                                                  'ahcys_c': 1,
                                                  'h_c': 1}},

                     'Y_at_38': {'machines': ['TruA_dim'],  
                                 'metabolites': {}},

                     'ac4C_at_34': {'machines': ['TmcAL_mono'],
                                    'metabolites': {'accoa_c': -1,
                                                    'coa_c': 1}},

                     'Y_at_39': {'machines': ['TruA_dim'],  
                                 'metabolites': {}},

                     # YhhP, YheLMN, YccK involved in sulfur transferase
                     # activity. TrmU catalyzes the addition of sulfur to
                     # uridine



                     'm6A_at_37': {'machines': ['RlmN_mono'],
                                   'metabolites': {'amet_c': -1,
                                                   'ahcys_c': 1,
                                                   'h_c': 1}},


                     'ms2i6A_at_37': {'machines': ['MiaA_dim'],
                                      'carriers': {
                                      'IscS_mod_2:pydx5p_mod_1:SH': -1,
                                      'IscS_mod_2:pydx5p': 1,
                                      'fldrd_c': -1,
                                      'fldox_c': 1, },
                                      'metabolites': {'dmpp_c': -1,
                                                      'amet_c': -2,
                                                      'ppi_c': 1,
                                                      'ahcys_c': 1,
                                                      'h_c': 2,
                                                      'met_L_c': 1,
                                                      'dad_5_c': 1,
                                                      }},

                     'D_at_21': {'machines': ['generic_Dus'],  
                                 'metabolites': {'nadph_c': -1,
                                                 'h_c': -1,
                                                 'nadp_c': 1}},

                     'm1G_at_37': {'machines': ['TrmD_dim'],  
                                   'metabolites': {'amet_c': -1,
                                                   'ahcys_c': 1,
                                                   'h_c': 1}},


                     'k2C_at_34': {'machines': ['TilS_mono'],  
                                   'metabolites': {'atp_c': -1,
                                                   'lys_L_c': -1,
                                                   'ppi_c': 1,
                                                   'amp_c': 1,
                                                   'h_c': 2}},

                     'I_at_34': {'machines': ['TadA_dim'],
                                 'metabolites': {'h2o_c': -1, 'h_c': -1,
                                                 'nh4_c': 1}},

                     'i6A_at_37': {'machines': ['MiaA_dim'],
                                   'metabolites': {'dmpp_c': -1,
                                                   'ppi_c': 1}},

                     }

modification_info = {'D': {'elements': {'H': 2}, 'charge': 0},
                     'i6A': {'elements': {'C': 5, 'H': 8}, 'charge': 0},
                     'I': {'elements': {'N': -1, 'H': -1, 'O': 1},
                           'charge': 0},
                     'k2C': {'elements': {'O': 1, 'N': 2, 'H': 12, 'C': 6},
                             'charge': 0},
                     'Y': {'elements': {}, 'charge': 0},
                     'm1G': {'elements': {'H': 2, 'C': 1}, 'charge': 0},
                     'ms2i6A': {'elements': {'C': 6, 'H': 10, 'S': 1},
                                'charge': 0},

                     'Um': {'elements': {'H': 2, 'C': 1}, 'charge': 0},
                     'm6A': {'elements': {'H': 2, 'C': 1}, 'charge': 0},

                     'ac4C': {'elements': {'H': 2, 'C': 2, 'O': 1},
                              'charge': 0},

                     'm6t6A': {'elements': {'C': 6, 'O': 4, 'N': 1, 'H': 9},
                               'charge': 0},
                     's4U': {'elements': {'O': -1, 'S': 1}, 'charge': 0},
                     'm2A': {'elements': {'H': 2, 'C': 1}, 'charge': 0},
                     'Q': {'elements': {'C': 7, 'O': 2, 'H': 11}, 'charge': 1},
                     'cmo5U': {'elements': {'C': 2, 'O': 3, 'H': 2},
                               'charge': 0},
                     'm5U': {'elements': {'C': 1, 'H': 2}, 'charge': 0},
                     'acp3U': {'elements': {'C': 4, 'H': 7, 'N': 1, 'O': 2},
                               'charge': 0},
                     'm7G': {'elements': {'C': 1, 'H': 2}, 'charge': 0},
                     't6A': {'elements': {'C': 5, 'N': 1, 'O': 4, 'H': 6},
                             'charge': 0}
                     }


def add_trna_modification_procedures(model):

    modifications = trna_modification.copy()
    modifications = correct_trna_modifications(modifications)

    for mod, components in iteritems(modifications):
        trna_mod = cobrame.SubreactionData(mod, model)
        trna_mod.enzyme = components['machines']
        trna_mod.stoichiometry = components['metabolites']
        trna_mod.keff = 65.  # iOL uses 65 for all tRNA mods
        if 'carriers' in components.keys():
            for carrier, stoich in components['carriers'].items():
                if stoich < 0:
                    trna_mod.enzyme += [carrier]
                trna_mod.stoichiometry[carrier] = stoich

        # Add element contribution from modification to tRNA
        trna_mod._element_contribution = \
            modification_info[mod.split('_')[0]]['elements']

    return modifications
