from __future__ import division, absolute_import, print_function

from cobrame import SubreactionData, Complex
from cobrame.util import dogma


initiation_subreactions = {
    'Translation_initiation_factor_InfA':
        {'enzymes': 'InfA_mono',
         'stoich': {}},

    'Translation_initiation_factor_InfC':
        {'enzymes': 'InfC_mono',
         'stoich': {}},

    'Translation_gtp_initiation_factor_InfB':
        {'enzymes': 'InfB_mono',
         'stoich': {'gtp_c': -1,
                    'h2o_c': -1,
                    'h_c': 1,
                    'pi_c': 1,
                    'gdp_c': 1}},

    'fmet_addition_at_START':
        {'enzymes': ['InfB_mono',
                     'Fmt_mono_mod_mg2_mod_k'],
         'stoich': {'10fthf_c': -1, 'thf_c': 1,
                    'generic_tRNA_START_met_L_c': -1},
         'element_contribution': {'C': 1, 'O': 1}}
   }

elongation_subreactions = {'FusA_mono_elongation': {'enzymes': ['FusA_mono'],
                                                    'stoich': {'gtp_c': -1,
                                                               'h2o_c': -1,
                                                               'h_c': 1,
                                                               'pi_c': 1,
                                                               'gdp_c': 1}},

                           'Tuf_gtp_regeneration': {'enzymes': ['Tsf_mono'],
                                                    'stoich': {}}}

# TODO Go through and double check elongation/termination ATP usage etc.
termination_subreactions = {'PrfA_mono_mediated_termination':
                            {'enzymes': ['PrfA_mono'],
                             'stoich': {}},

                            'PrfB_mono_mediated_termination':
                            {'enzymes': ['PrfB_mono'],
                             'stoich': {}},

                            'generic_RF_mediated_termination':
                            {'enzymes': ['generic_RF'],
                             'stoich': {}},

                            'N_terminal_methionine_cleavage':
                            {'enzymes': ['MapA_mono_mod_2:fe2'],
                             'stoich': {'h2o_c': -1,
                                        'met_L_c': 1, 'h_c': 1},
                             'element_contribution': {'H': -10, 'O': -1,
                                                      'C': -5, 'N': -1,
                                                      'S': -1}},

                            'peptide_deformylase_processing':
                            {'enzymes': ['DefA_mono_mod_1:fe2'],
                             'stoich': {'h2o_c': -1,
                                        'for_c': 1},
                             'element_contribution':
                                 {'H': 1, 'O': -1, 'C': -1}},

                            # This is a GTPS

                            'ribosome_recycler':
                            {'enzymes': ['Frr_mono'],
                             'stoich': {}},

                            'GroEL_dependent_folding':
                            {'enzymes': ['GroEL_14', 'cisGroES_hepta',
                                         'transGroES_hepta'],
                             'stoich': {'atp_c': -7,
                                        'h2o_c': -7,
                                        'h_c': 7,
                                        'adp_c': 7,
                                        'pi_c': 7}},

                            # DnaK is correct
                            'DnaK_dependent_folding':
                            {'enzymes': ['DnaK_mono', 'DnaJ_dim_mod_4:zn2',
                                         'GrpE_dim'],
                             'stoich': {'atp_c': -1,
                                        'h2o_c': -1,
                                        'h_c': 1,
                                        'adp_c': 1,
                                        'pi_c': 1}}
                            }

# Subreaction for translation termination
translation_stop_dict = {'UAG': 'PrfA_mono',
                         'UGA': 'PrfB_mono',
                         'UAA': 'generic_RF'}

translation_start_codons = {"AUG", "GUG", "UUG", "AUU", "CUG"}

# Dictionary of frame shift mutations
frameshift_dict = {'BSU35290': '3627139:3628240'}

peptide_processing_subreactions = {"peptide_deformylase_processing",
                                   "ribosome_recycler"}


def add_translation_subreactions_to_model(me_model):
    # add general subreactions
    for rxn, info in elongation_subreactions.items():
        data = SubreactionData(rxn, me_model)
        data.enzyme = info['enzymes']
        data.stoichiometry = info['stoich']

    # add subreactions associated with termination and postprocessing
    for rxn, info in termination_subreactions.items():
        data = SubreactionData(rxn, me_model)
        data.enzyme = info['enzymes']
        data.stoichiometry = info['stoich']
        data._element_contribution = info.get('element_contribution', {})

    # add subreactions associated with translation initiation
    for rxn, info in initiation_subreactions.items():
        data = SubreactionData(rxn, me_model)
        data.enzyme = info['enzymes']
        data.stoichiometry = info['stoich']
        data._element_contribution = info.get('element_contribution', {})


def add_charged_trna_subreactions(me_model):
    # create subreaction for each codon. this will be used to model
    # the addition of charged tRNAs to the elongating peptide
    for codon in dogma.codon_table:
        if dogma.codon_table[codon] == '*':
            stop_codon = codon.replace('T', 'U')
            stop_enzyme = translation_stop_dict.get(stop_codon)
            me_model.add_metabolites([Complex(stop_enzyme)])

            subreaction_data = SubreactionData(
                stop_codon + '_' + stop_enzyme + '_mediated_termination',
                me_model)
            subreaction_data.enzyme = stop_enzyme
            subreaction_data.stoichiometry = {}
        else:
            full_aa = dogma.amino_acids[dogma.codon_table[codon]]
            amino_acid = full_aa.split('_')[0]
            subreaction_data = SubreactionData(
                amino_acid + '_addition_at_' + codon.replace('T', 'U'),
                me_model)
            trna = 'generic_tRNA_' + codon.replace('T', 'U') + '_' + full_aa
            subreaction_data.enzyme = 'generic_Tuf'  # Default AA loader enzyme

            # Accounts for GTP hydrolyzed by EF-TU and the ATP hydrolysis to
            # AMP required to add the amino acid to the tRNA
            subreaction_data.stoichiometry = {'gtp_c': -1, 'h2o_c': -2,
                                              'gdp_c': 1, 'h_c': 2, 'pi_c': 1,
                                              'ppi_c': 1, 'amp_c': 1,
                                              'atp_c': -1,
                                              trna: -1}

    # Add subreactions for start codon and selenocysteine
    for rxn, info in special_trna_subreactions.items():
        data = SubreactionData(rxn, me_model)
        data.enzyme = info['enzymes']
        data.stoichiometry = info['stoich']
        data._element_contribution = info.get('element_contribution', {})


# N terminal methionine cleaved
methionine_cleaved = ['BSU00110', 'BSU00120', 'BSU00130', 'BSU00140', 'BSU00150', 'BSU00160',
                      'BSU00170', 'BSU00180', 'BSU00190', 'BSU00200', 'BSU00210', 'BSU00220',
                      'BSU00230', 'BSU00240', 'BSU00250', 'BSU00260', 'BSU00270', 'BSU00280',
                      'BSU00290', 'BSU00300', 'BSU00310', 'BSU00320', 'BSU00330', 'BSU00340',
                      'BSU00350', 'BSU00360', 'BSU00370', 'BSU00380', 'BSU00390', 'BSU00400',
                      'BSU00410', 'BSU00420', 'BSU00430', 'BSU00440', 'BSU00450', 'BSU00460',
                      'BSU00470', 'BSU00480', 'BSU00490', 'BSU00500']

folding_dict = {                                                                          
    'GroEL_dependent_folding': ['BSU00170', 'BSU00180', 'BSU00190', 'BSU00200', 'BSU00210', 'BSU00220',
                                'BSU00230', 'BSU00240', 'BSU00250', 'BSU00260', 'BSU00270', 'BSU00280',
                                'BSU00290', 'BSU00300', 'BSU00310', 'BSU00320', 'BSU00330', 'BSU00340',
                                'BSU00350', 'BSU00360', 'BSU00370', 'BSU00380', 'BSU00390', 'BSU00400',
                                'BSU00410', 'BSU00420', 'BSU00430', 'BSU00440', 'BSU00450', 'BSU00460',
                                'BSU00470', 'BSU00480', 'BSU00490', 'BSU00500'],
    'DnaK_dependent_folding': ['BSU00170', 'BSU00180', 'BSU00190', 'BSU00200', 'BSU00210', 'BSU00220',
                                'BSU00230', 'BSU00240', 'BSU00250', 'BSU00260', 'BSU00270', 'BSU00280',
                                'BSU00290', 'BSU00300', 'BSU00310', 'BSU00320', 'BSU00330', 'BSU00340',
                                'BSU00350', 'BSU00360', 'BSU00370', 'BSU00380', 'BSU00390', 'BSU00400',
                                'BSU00410', 'BSU00420', 'BSU00430', 'BSU00440', 'BSU00450', 'BSU00460',
                                'BSU00470', 'BSU00480', 'BSU00490', 'BSU00500']}


