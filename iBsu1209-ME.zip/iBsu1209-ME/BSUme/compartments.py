import cobrame
from ecolime.util.helper_functions import get_base_complex_data
from collections import defaultdict


def _return_compartments_of_complexes(model, cplx):
    try:
        data = model.process_data.get_by_id(cplx.id)
        print(cplx.id)
    except KeyError:
        data = get_base_complex_data(model, cplx.id)
        print(cplx.id)

    mem_dict = defaultdict(int)
    for s in data.stoichiometry:
        if '_cytosol' in s:
            mem_dict['c'] += 0
        elif '_ribosome' in s:
            mem_dict['r'] += 1
        elif '_plasma_membrane' in s:
            mem_dict['pm'] += 1
        elif '_cell_wall' in s:
            mem_dict['cw'] += 1
        elif '_Extra-organism' in s:
            mem_dict['e'] += 1

    # if no membrane associated with membrane subunit, assume complex is
    # cytosolic
    # if len(mem_dict) == 0:
    #     return 'c'
    # if only one membrane is represented in protein subunits, use this
    # membrane for the compartment
    if len(mem_dict) == 1:
        return mem_dict.popitem()[0]
    # if multiple membrane compartements are represented, use generic "m" for
    # "membrane" for now
    else:
        return 'pm'


def add_compartments_to_model(model):
    """Firsts adds compartments based on suffix of metabolite ID. If metabolite
    is a complex, the protein subunit stoichiometry is used to infer
    compartment. All remaining metabolites without a compartment suffix (RNAs,
    generic metabolites, nonmembrane proteins, etc.) are assumed to be
    cytosolic"""

    for m in model.metabolites:
        if m.compartment:
            continue
        if isinstance(m, cobrame.Constraint):
            m.compartment = 'mc'
        elif '_ribosome' in m.id:
            m.compartment = 'r'
        elif '_cell_wall' in m.id:
            m.compartment = 'cw'
        elif '_plasma_membrane' in m.id or m.id.endswith('_pm'):
            m.compartment = 'pm'
        elif m.id.endswith('_e'):
            m.compartment = 'e'
        elif m.id.endswith('_c'):
            m.compartment = 'c'
        elif isinstance(m, cobrame.Complex):
            m.compartment = _return_compartments_of_complexes(model, m)
        else:
            m.compartment = 'c'