from __future__ import division, absolute_import, print_function

from six import iteritems

from cobrame import ComplexData, SubreactionData

transcription_subreactions = {
    'Transcription_normal_rho_independent':
        {'enzymes': ['Mfd_mono_mod_1:mg2', 'NusA_mono',
                     'GreA_mono', 'GreB_mono', 'RpoY_mono_mod_1:mg2'],
         'stoich': {}},
    'Transcription_normal_rho_dependent':
        {'enzymes': ['Mfd_mono_mod_1:mg2', 'NusG_mono',
                     'GreA_mono', 'GreB_mono', 'RpoY_mono_mod_1:mg2',
                     'Rho_hexa_mod_3:mg2'],
         'stoich': {'atp_c': -3,
                    'h2o_c': -3,
                    'adp_c': 3,
                    'pi_c': 3,
                    'h_c': 3}},
    'Transcription_stable_rho_independent':
        {'enzymes': ['Mfd_mono_mod_1:mg2', 'NusA_mono',
                     'GreA_mono', 'GreB_mono', 'RpoY_mono_mod_1:mg2',
                     'RpsJ_mono',  'RpsD_mono', 'RplC_mono', 'RplD_mono',
                     'RplM_mono'],
         'stoich': {}},
    'Transcription_stable_rho_dependent':
        {'enzymes': ['Mfd_mono_mod_1:mg2', 'NusA_mono',
                     'GreA_mono', 'GreB_mono', 'RpoZ_mono_mod_1:mg2',
                     'Rho_hexa_mod_3:mg2',  'RpsJ_mono',  'RpsD_mono',
                     'RplC_mono', 'RplD_mono', 'RplM_mono'],
         'stoich': {'atp_c': -3,
                    'h2o_c': -3,
                    'adp_c': 3,
                    'pi_c': 3,
                    'h_c': 3}}
}

sigma_factor_complex_to_rna_polymerase_dict = {
    # this is notation used in Tu_from_ecocyc, protein_complexes (and below)
    'sigI_mono': 'CPLX8J2-53',      'sigG_mono': 'CPLX8J2-59',      'sigZ_mono': 'CPLX8J2-48',
    'sigA_mono': 'CPLX8J2-52',      'sigE_mono': 'CPLX8J2-61',      'sigV_mono': 'CPLX8J2-47',
    'sigD_mono': 'CPLX8J2-54',      'spoIIIC_mono': 'CPLX8J2-60',   'sigY_mono': 'CPLX8J2-46',
    'sigH_mono': 'CPLX8J2-55',      'spoIVCB_mono': 'CPLX8J2-60',   'sigM_mono': 'CPLX8J2-45',
    'sigB_mono': 'CPLX8J2-56',      'ylaC_mono': 'CPLX8J2-51',      'sigL_mono': 'CPLX8J2-57',
    'sigW_mono': 'CPLX8J2-50',      'sigF_mono': 'CPLX8J2-58',      'sigX_mono': 'CPLX8J2-49'}

rna_polymerase_id_by_sigma_factor = {
    'CPLX8J2-53': {'sigma_factor': 'sigI_mono',
                  'polymerase': 'hRNAP_mod_1:zn2_mod_2:mg2'},
    'CPLX8J2-52': {'sigma_factor': 'sigA_mono',
                   'polymerase': 'hRNAP_mod_1:zn2_mod_2:mg2'},
    'CPLX8J2-54': {'sigma_factor': 'sigD_mono',
                  'polymerase': 'hRNAP_mod_1:zn2_mod_2:mg2'},
    'CPLX8J2-55': {'sigma_factor': 'sigH_mono',
                    'polymerase': 'hRNAP_mod_1:zn2_mod_2:mg2'},
    'CPLX8J2-56': {'sigma_factor': 'sigB_mono',
                    'polymerase': 'hRNAP_mod_1:zn2_mod_2:mg2'},
    'CPLX8J2-57': {'sigma_factor': 'sigL_mono',
                    'polymerase': 'hRNAP_mod_1:zn2_mod_2:mg2'},
    'CPLX8J2-58': {'sigma_factor': 'sigF_mono',
                   'polymerase': 'hRNAP_mod_1:zn2_mod_2:mg2'},
    'CPLX8J2-59': {'sigma_factor': 'sigG_mono',
                  'polymerase': 'hRNAP_mod_1:zn2_mod_2:mg2'},
    'CPLX8J2-61': {'sigma_factor': 'sigE_mono',
                   'polymerase': 'hRNAP_mod_1:zn2_mod_2:mg2'},
    'CPLX8J2-60': {'sigma_factor': 'spoIIIC_mono',
                  'polymerase': 'hRNAP_mod_1:zn2_mod_2:mg2'},
    'CPLX8J2-60': {'sigma_factor': 'spoIVCB_mono',
                    'polymerase': 'hRNAP_mod_1:zn2_mod_2:mg2'},
    'CPLX8J2-51': {'sigma_factor': 'ylaC_mono',
                    'polymerase': 'hRNAP_mod_1:zn2_mod_2:mg2'},
    'CPLX8J2-50': {'sigma_factor': 'sigW_mono',
                    'polymerase': 'hRNAP_mod_1:zn2_mod_2:mg2'},
    'CPLX8J2-49': {'sigma_factor': 'sigX_mono',
                   'polymerase': 'hRNAP_mod_1:zn2_mod_2:mg2'},
    'CPLX8J2-48': {'sigma_factor': 'sigZ_mono',
                   'polymerase': 'hRNAP_mod_1:zn2_mod_2:mg2'},
    'CPLX8J2-47': {'sigma_factor': 'sigV_mono',
                   'polymerase': 'hRNAP_mod_1:zn2_mod_2:mg2'},
    'CPLX8J2-46': {'sigma_factor': 'sigY_mono',
                   'polymerase': 'hRNAP_mod_1:zn2_mod_2:mg2'},
    'CPLX8J2-45': {'sigma_factor': 'sigM_mono',
                   'polymerase': 'hRNAP_mod_1:zn2_mod_2:mg2'}}

rna_polymerases = {'CPLX8J2-53', 'CPLX8J2-59', 'CPLX8J2-48', 'CPLX8J2-52', 'CPLX8J2-61',
                   'CPLX8J2-47', 'CPLX8J2-54', 'CPLX8J2-60', 'CPLX8J2-46', 'CPLX8J2-55',
                   'CPLX8J2-60', 'CPLX8J2-45', 'CPLX8J2-56', 'CPLX8J2-51', 'CPLX8J2-57',
                   'CPLX8J2-50', 'CPLX8J2-58', 'CPLX8J2-49'}

rna_degradosome = {'Eno_dim': 1, 'PnpA_trim': 1,
                   'RNase_Y_tetra': 1, 'cshA_dim': 1,
                   'nrnB_dim': 1}

excision_machinery = {                                                                 
    'rRNA_containing': ['RNase_Y_tetra', 'RNase_P_cplx',
                        'generic_RNase', 'RNase_m5', 'RNase_m16', 'RNase_m23',
                        'RNase_III_dim', 'RNase_J1_dim'],
    'monocistronic': ['RNase_E_tetra', 'RNase_P_cplx',
                      'generic_RNase'],
    'polycistronic_wout_rRNA': ['RNase_E_tetra',
                                'RNase_P_cplx', 'generic_RNase',
                                'RNase_III_dim', 'RNase_J1_dim']}


def add_rna_polymerase_complexes(me_model, verbose=True):

    for cplx, components in iteritems(rna_polymerase_id_by_sigma_factor):
        rnap_complex = ComplexData(cplx, me_model)
        rnap_components = rnap_complex.stoichiometry
        sigma_factor = components['sigma_factor']
        polymerase = components['polymerase']

        rnap_components[sigma_factor] = 1
        rnap_components[polymerase] = 1

        rnap_complex.create_complex_formation(verbose=verbose)


def add_rna_splicing(me_model):

    # Ecoli has three alternatie mechanisms for splicing RNA, depending
    # on what RNA types the TU contains
    excision_types = ['rRNA_containing', 'monocistronic',
                      'polycistronic_wout_rRNA']

    for excision_type in excision_types:
        complex_data = ComplexData(excision_type + "_excision_machinery",
                                   me_model)

        for machine in excision_machinery[excision_type]:
            complex_data.stoichiometry[machine] = 1

        complex_data.create_complex_formation()
        modification = SubreactionData(excision_type + "_excision", me_model)
        modification.enzyme = complex_data.id

    # Loop through transcription reactions and add appropriate splicing
    # machinery based on RNA types and number of splices required
    for t in me_model.transcription_data:
        n_excised = sum(t.excised_bases.values())
        n_cuts = len(t.RNA_products) * 2
        if n_excised == 0 or n_cuts == 0:
            continue
        rna_types = list(t.RNA_types)
        n_trna = rna_types.count("tRNA")

        if "rRNA" in set(rna_types):
            t.subreactions["rRNA_containing_excision"] = n_cuts
        elif n_trna == 1:
            t.subreactions["monocistronic_excision"] = n_cuts
        elif n_trna > 1:
            t.subreactions["polycistronic_wout_rRNA_excision"] = n_cuts
        else:  # only applies to rnpB
            t.subreactions["monocistronic_excision"] = n_cuts

        # The non functional RNA segments need degraded back to nucleotides
        # TODO check if RNA_degradation requirement is per nucleotide
        t.subreactions["RNA_degradation_machine"] = n_cuts
        t.subreactions["RNA_degradation_atp_requirement"] = n_excised
