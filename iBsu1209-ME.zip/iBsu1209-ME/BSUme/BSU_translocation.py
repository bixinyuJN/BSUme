from __future__ import print_function, absolute_import, division

from collections import defaultdict

from cobrame.core.processdata import PostTranslationData
from cobrame.core.reaction import PostTranslationReaction

pathway = {'sec': {'enzymes': {'BSU35300_MONOMER': {'length_dependent': True,
                                                'fixed_keff': False},
                               'BSU01000_MONOMER': {'length_dependent': True,
                                            'fixed_keff': False}},
                   'keff': 4.,
                   'length_dependent_energy': True,
                   'stoichiometry': {'atp_c': -1./25., 'h2o_c': -1./25.,
                                     'adp_c': 1./25., 'pi_c': 1./25.,
                                     'h_c': 1./25.}},

           'tat': {'enzymes': {'BSU17710_MONOMER': {'length_dependent': False,
                                              'fixed_keff': False},
                               'BSU02630_MONOMER': {'length_dependent': False,
                                                'fixed_keff': False}},
                   'keff': 0.0125,
                   'length_dependent_energy': False,
                   'stoichiometry': {}},

           'tat_alt': {'enzymes': {'BSU17710_MONOMER': {'length_dependent': False,
                                                  'fixed_keff': False},
                                   'BSU05980_MONOMER': {'length_dependent': False,
                                                    'fixed_keff': False}},
                       'keff': 0.0125,
                       'length_dependent_energy': False,
                       'stoichiometry': {}},

           'yidC': {'enzymes': {'BSU41040_MONOMER': {'length_dependent': True,
                                                 'fixed_keff': False},
                                'BSU23890_MONOMER': {'length_dependent': True,
                                                    'fixed_keff': False}},
                    'keff': 20.,
                    'length_dependent_energy': False,
                    'stoichiometry': {'gtp_c': -1., 'h2o_c': -1., 'gdp_c': 1.,
                                      'pi_c': 1., 'h_c': 1.}},

           'secA': {'enzymes': {'BSU35300_MONOMER': {'length_dependent': True,
                                                 'fixed_keff': False}},
                    'keff': 4.,
                    'length_dependent_energy': True,
                    'stoichiometry': {'atp_c': -1./3./25., 'h2o_c': -1./3./25.,
                                      'adp_c': 1./3./25., 'pi_c': 1./3./25.,
                                      'h_c': 1./3./25.}},

           'srp_yidC': {'enzymes': {'BSU15970_MONOMER': {'length_dependent': True,
                                                 'fixed_keff': False},
                                    'BSU41040_MONOMER': {'length_dependent': True,
                                                     'fixed_keff': False},
                                    'BSU23890_MONOMER': {'length_dependent': True,
                                                     'fixed_keff': False},
                                    'BSU01000_MONOMER': {'length_dependent': True,
                                                 'fixed_keff': False}},
                    'keff': 20.,
                    'length_dependent_energy': False,
                    'stoichiometry': {'gtp_c': -1., 'h2o_c': -1.,
                                      'gdp_c': 1., 'pi_c': 1., 'h_c': 1.}},

           'srp': {'enzymes': {'BSU15950_MONOMER': {'length_dependent': False,
                                                'fixed_keff': True},
                               'BSU01000_MONOMER': {'length_dependent': True,
                                            'fixed_keff': False}},
                   'keff': 20.,
                   'length_dependent_energy': False,
                   'stoichiometry': {'gtp_c': -2., 'h2o_c': -2., 'gdp_c': 2.,
                                     'pi_c': 2., 'h_c': 2.}}
           }
abbreviation_to_pathway = {'s': 'sec_translocation',
                           't': ['tat_translocation', 'tat_translocation_alt'],
                           'y': 'yidC_translocation',
                           'a': 'secA_translocation',
                           'p': 'srp_yidC_translocation',
                           'r': 'srp_translocation'}

# Some proteins require different numbers of a complex in order to be
# translocated by a pathway
multipliers = {'BSU41040_MONOMER': {'BSU24330': 2., 'BSU36800': 2.},
               'BSU02630_MONOMER': {'BSU22560': 20.0,  'BSU25710': 22.0, 'BSU12160': 15.5,
                                 'BSU33320': 21.0, 'BSU39610': 21.0,'BSU12170': 15.5,
                                 'BSU18500': 14.0, 'BSU14630': 6.25, 'BSU23040': 20.0},
               'BSU17710_MONOMER': {'BSU22560': 20.0,  'BSU12160': 22.0, 'BSU12170': 15.5,
                                 'BSU33320': 21.0, 'BSU12160': 15.5,'BSU18500': 14.0,
                                 'BSU14630': 6.25, 'BSU23040': 20.0}}

multipliers_protein_keys = defaultdict(dict)
for enzyme, value in multipliers.items():
    for bnum in value.keys():
        multipliers_protein_keys['protein_' + bnum][enzyme] = value[bnum]

mmol = 6.022e20  # number of molecules per mmol
nm2_per_m2 = 1e18  # used to convert nm^2 to m^2


def add_translocation_pathways(model, pathways_df, membrane_constraints=False):

    def add_translocation_data_and_reaction(model, pathways, preprocessed_id,
                                            processed_id, compartment,
                                            peptide_data, alt=False):

        suffix = '_alt' if alt else ''

        data = PostTranslationData('translocation_' + preprocessed_id + suffix,
                                   model, processed_id, preprocessed_id)

        data.translocation = pathways

        data.translocation_multipliers = \
            multipliers_protein_keys.get(preprocessed_id, {})

        # Add protein surface area constraint
        if membrane_constraints and compartment != 'Periplasm':
            protein = peptide_data.protein
            protein_met = model.metabolites.get_by_id('protein_' + protein)
            mass = protein_met.formula_weight / 1000.  # in kDa
            membrane_thickness = model.global_info['membrane_thickness']
            thickness = membrane_thickness[compartment]
            # Relationship uses protein molecular in kDa
            # Adds surface area constraint in units of m^2/mmol
            data.surface_area['SA_protein_' + compartment] = \
                (1.21 / thickness * 2.) * mass * mmol / nm2_per_m2

        rxn = PostTranslationReaction('translocation_' + peptide_data.id +
                                      suffix)
        rxn.posttranslation_data = data
        model.add_reaction(rxn)
        rxn.update()

    # loop through all translation data and add translocation rxns/surface area
    # constraints if they are membrane proteins
    for peptide_data in model.translation_data:

        # extract translocation info if peptide contained in complex
        # stoichiometry
        translocation_info = pathways_df[
            pathways_df.Protein.str.match(peptide_data.id)]
        # iterate if protein is not in a membrane complex
        if len(translocation_info) == 0:
            continue

        # Assign preprocessed and processed (translocated) peptide ids
        compartment = translocation_info.Protein_compartment.values[0]
        processed_id = 'protein_' + peptide_data.id + '_' + compartment
        preprocessed_id = 'protein_' + peptide_data.id

        # compile translocation pathways for each membrane protein
        pathways = set()
        pathways_alt = set()
        for abbrev in translocation_info.translocase_pathway.values[0]:
            pathway_name = abbreviation_to_pathway[abbrev]

            # The tat translocation pathway can use an alternate enzyme
            if type(pathway_name) == list:
                pathways.add(pathway_name[0])
                pathways_alt.add(pathway_name[1])
            else:
                pathways.add(pathway_name)
                pathways_alt.add(pathway_name)

        add_translocation_data_and_reaction(model, pathways, preprocessed_id,
                                            processed_id, compartment,
                                            peptide_data)

        # if there's an alternative pathway (tat) add this reaction as well
        if pathways != pathways_alt:
            add_translocation_data_and_reaction(model, pathways_alt,
                                                preprocessed_id, processed_id,
                                                compartment, peptide_data,
                                                alt=True)


lipoprotein_precursors = {'lytA': 'BSU35640','cwlQ': 'BSU11570', 'MetP': 'BSU32740','yjbJ': 'BSU11570'}

lipid_modifications = ['phlg_edio_c', 'phlg_dit16_c']


def add_lipoprotein_formation(model, compartment_dict,
                              membrane_constraints=False, update=True):

    # loop through all proteins which need lipid modifications (lipoproteins)
    for protein in lipoprotein_precursors.values():
        compartment = compartment_dict.get(protein)
        protein_met = model.metabolites.get_by_id('protein_' + protein)
        mass = protein_met.formula_weight / 1000.  # in kDa

        processed_id = 'protein_' + protein + '_lipoprotein_' + compartment
        preprocessed_id = 'protein_' + protein + '_' + compartment

        def add_lipoprotein_data_and_reaction(first_lipid, second_lipid):

            # Add PostTranslation Data, modifications and surface area
            data = PostTranslationData(reaction_prefix + '_' + second_lipid,
                                       model, processed_id, preprocessed_id)
            data.subreactions['mod_' + first_lipid] = 1
            data.subreactions['mod_' + second_lipid] = 1
            data.biomass_type = 'lipid_biomass'

            if membrane_constraints:
                thickness_dict = model.global_info['membrane_thickness']
                thickness = thickness_dict['Outer_Membrane']

                # From Liu et al. x2 for each to account for each leaflet
                protein_SA = 1.21 / thickness * 2 * mass * mmol / nm2_per_m2
                data.surface_area = {'SA_protein_' + compartment: -protein_SA,
                                     'SA_lipoprotein': 1. * mmol / nm2_per_m2}

            # Add Reaction to model and associated it with its data
            rxn = PostTranslationReaction(reaction_prefix + '_' + second_lipid)
            model.add_reaction(rxn)
            rxn.posttranslation_data = data
            if update:
                rxn.update()

        for mod in lipid_modifications:
            reaction_prefix = protein + '_lipid_modification_' + mod
            add_lipoprotein_data_and_reaction(mod, 'phlg_dit16_c')
            add_lipoprotein_data_and_reaction(mod, 'phlg_dit16_c')
